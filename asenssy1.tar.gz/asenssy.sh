echo "" > linux_non-prod2.csv

while IFS=$'\t' read -r i y; do
    # Capture the Ansible output
    output=$(ansible all -i "$i," -b -o -a "bash -c 'df -hT $y'")

    # Check if host is unreachable
    if echo "$output" | grep -q "UNREACHABLE!"; then
        fs_type="UNREACHABLE"
    else
        # Extract filesystem type using awk
        fs_type=$(echo "$output" | awk '{print $16}')
        
        # If fs_type is empty or equals the hostname, then something went wrong
        if [ -z "$fs_type" ] || [ "$fs_type" == "$i" ]; then
            fs_type="ERROR_EXTRACTING"
        fi
    fi

    # Append to the new CSV
    echo "$i,$y,$fs_type" >> linux_non-prod2.csv

done < filesystems.csv

